Microsoft Azure SDK for Python


